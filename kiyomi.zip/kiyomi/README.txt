Credits:

    - Kiyomi Sato MPT Pack Revised by Doki Senate       https://www.youtube.com/@dokisenate66
    - Some Used Assets By u/yagamirai10                     https://www.reddit.com/user/yagamirai10/
    - Original Sprites By u/StormBlazed76                      https://www.reddit.com/user/StormBlazed76/